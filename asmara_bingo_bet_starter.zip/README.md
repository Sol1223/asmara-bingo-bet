# Asmara Bingo Bet — Telegram Mini App starter

A colorful, bilingual (English / Amharic) 75-ball Bingo **free-play demo**.
No deposits, paid entry, cash prizes, wallets, or payouts are implemented.

## Included
- Telegram Mini App-friendly responsive interface
- English / Amharic language toggle
- 75-ball Bingo card generation (B-I-N-G-O columns)
- Free demo room with number calling and automatic card marking
- Bingo line detection (horizontal, vertical, diagonal)
- FastAPI backend with an in-memory demo game API
- Telegram WebApp initialization hook (works in ordinary browser preview too)

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload
```

Open http://127.0.0.1:8000

The server uses in-memory state for development. Restarting it resets the demo.
It is not production multiplayer storage. For a real public launch, replace the
in-memory store with PostgreSQL/Redis, add authentication and rate limits, and
use an authorized admin flow for drawing numbers.

## Connect to Telegram

1. Open [@BotFather](https://t.me/BotFather), create a bot with `/newbot`.
2. Deploy this app to a host that provides a public HTTPS URL.
3. In BotFather, configure the Mini App / Web App URL for your bot using the
   current BotFather menu.
4. Set the deployed URL as the bot's Mini App URL.
5. Open the Mini App from the bot's menu button.

The app reads `window.Telegram.WebApp` when available and calls `ready()` /
`expand()`. It does not trust client-supplied Telegram user data as proof of
identity. Before public launch, validate Telegram `initData` on the server
using Telegram's documented HMAC procedure.

Official docs: https://core.telegram.org/bots/webapps

## Demo controls

- **Join free game** creates a card for the current browser session.
- **Call next number** calls a random number from 1–75.
- **Auto-mark** highlights called numbers on the card.
- **BINGO!** checks for a completed row, column, or diagonal.

This is a starter demo, not a regulated gaming product. Keep it free-to-play
until you have obtained local legal advice and any required approvals for
your intended countries and audience.
