from __future__ import annotations
import random
import uuid
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

app = FastAPI(title="Asmara Bingo Bet Demo API")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Development-only in-memory game state. Replace with persistent storage for production.
called_numbers: List[int] = []
players: Dict[str, dict] = {}
remaining = set(range(1, 76))
winner: Optional[str] = None

def column_numbers(col: int) -> List[int]:
    low = col * 15 + 1
    return list(range(low, low + 15))

def make_card() -> List[List[Optional[int]]]:
    cols = []
    for col in range(5):
        cols.append(random.sample(column_numbers(col), 5))
    rows = [[cols[c][r] for c in range(5)] for r in range(5)]
    rows[2][2] = None  # free center
    return rows

def has_bingo(card: List[List[Optional[int]]], called: set[int]) -> bool:
    marked = lambda r, c: card[r][c] is None or card[r][c] in called
    lines = []
    lines.extend([[ (r, c) for c in range(5)] for r in range(5)])
    lines.extend([[(r, c) for r in range(5)] for c in range(5)])
    lines.append([(i, i) for i in range(5)])
    lines.append([(i, 4-i) for i in range(5)])
    return any(all(marked(r, c) for r, c in line) for line in lines)

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.get("/api/state")
def state():
    return {
        "called": called_numbers,
        "players": len(players),
        "winner": winner,
        "remaining": len(remaining),
    }

class JoinRequest(BaseModel):
    display_name: str = "Player"

@app.post("/api/join")
def join(req: JoinRequest):
    player_id = str(uuid.uuid4())
    card = make_card()
    players[player_id] = {"name": req.display_name[:32], "card": card}
    return {"player_id": player_id, "card": card, "called": called_numbers}

@app.post("/api/call")
def call_number():
    global winner
    if not remaining:
        raise HTTPException(status_code=400, detail="All numbers have been called. Reset the demo.")
    number = random.choice(tuple(remaining))
    remaining.remove(number)
    called_numbers.append(number)
    if winner is None:
        for pid, player in players.items():
            if has_bingo(player["card"], set(called_numbers)):
                winner = pid
                break
    return {"number": number, "called": called_numbers, "winner": winner}

@app.post("/api/reset")
def reset():
    global called_numbers, players, remaining, winner
    called_numbers = []
    players = {}
    remaining = set(range(1, 76))
    winner = None
    return {"ok": True}
