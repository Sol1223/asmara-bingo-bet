const I18N = {
 en: {
  demo:"FREE DEMO", eyebrow:"THE FUN STARTS HERE", welcome:"WELCOME TO", subtitle:"Your colorful 75-ball Bingo room. Play for fun with friends — no money, no deposits, just Bingo.",
  players:"PLAYERS IN ROOM",left:"NUMBERS LEFT",balls:"BINGO BALLS",yourCard:"YOUR CARD",bingoCard:"Bingo card",notJoined:"NOT JOINED",joined:"JOINED",joinPrompt:"Join the free game to get your card",autoMark:"Numbers are marked automatically",join:"JOIN FREE GAME",liveDraw:"LIVE DRAW",numberCaller:"Number caller",live:"LIVE DEMO",waiting:"Waiting for the first number",callNumber:"CALL NEXT NUMBER",calledNumbers:"CALLED NUMBERS",noneYet:"None yet",bingoChallenge:"Bingo challenge",winRule:"Complete any row, column or diagonal, then tap BINGO!",bingo:"BINGO!",howToWin:"HOW TO WIN",oneLine:"Complete one line",patternText:"Across, down, or diagonal. The center square is FREE.",safeTitle:"Free-play demo",safeText:"This starter has no payments, deposits, cash prizes or payouts.",footer:"Play fair. Have fun.",
  joinedToast:"You're in! Your Bingo card is ready.",drawToast:"Number called: ",needJoin:"Join the game first.",noBingo:"Not yet — keep playing!",bingoToast:"BINGO! Your card has a winning line.",gameOver:"All 75 numbers have been called. Reset the demo to play again.",winner:"A demo winner has been detected!"
 },
 am: {
  demo:"ነፃ ሙከራ",eyebrow:"ደስታው እዚህ ይጀምራል",welcome:"እንኳን ወደ",subtitle:"ባለ 75 ኳስ ቢንጎ ጨዋታ። ከጓደኞችዎ ጋር በነፃ ይጫወቱ — ያለ ገንዘብ ክፍያ።",
  players:"በጨዋታው ውስጥ ተጫዋቾች",left:"የቀሩ ቁጥሮች",balls:"የቢንጎ ኳሶች",yourCard:"የእርስዎ ካርድ",bingoCard:"የቢንጎ ካርድ",notJoined:"አልተቀላቀሉም",joined:"ተቀላቅለዋል",joinPrompt:"ካርድ ለማግኘት ነፃውን ጨዋታ ይቀላቀሉ",autoMark:"የተጠሩ ቁጥሮች በራስ-ሰር ይመረጣሉ",join:"ነፃ ጨዋታ ይቀላቀሉ",liveDraw:"ቀጥታ ዕጣ",numberCaller:"ቁጥር ጠሪ",live:"የቀጥታ ሙከራ",waiting:"የመጀመሪያውን ቁጥር በመጠበቅ ላይ",callNumber:"ቀጣዩን ቁጥር ጥራ",calledNumbers:"የተጠሩ ቁጥሮች",noneYet:"ገና የለም",bingoChallenge:"የቢንጎ ፈተና",winRule:"ረድፍ፣ ዓምድ ወይም ሰያፍ መስመር ያሟሉና ቢንጎን ይጫኑ!",bingo:"ቢንጎ!",howToWin:"እንዴት ማሸነፍ ይቻላል",oneLine:"አንድ መስመር ያሟሉ",patternText:"አግድም፣ ቁልቁል ወይም ሰያፍ። መሃሉ ነፃ ነው።",safeTitle:"ነፃ የሙከራ ጨዋታ",safeText:"በዚህ ስሪት ክፍያ፣ ተቀማጭ ገንዘብ ወይም የገንዘብ ሽልማት የለም።",footer:"በፍትሃዊነት ይጫወቱ። ይደሰቱ።",
  joinedToast:"ተቀላቅለዋል! የቢንጎ ካርድዎ ዝግጁ ነው።",drawToast:"የተጠራው ቁጥር፦ ",needJoin:"መጀመሪያ ጨዋታውን ይቀላቀሉ።",noBingo:"ገና አልተሟላም — ይቀጥሉ!",bingoToast:"ቢንጎ! ካርድዎ አሸናፊ መስመር አለው።",gameOver:"75ቱም ቁጥሮች ተጠርተዋል። እንደገና ይጀምሩ።",winner:"የሙከራ አሸናፊ ተገኝቷል!"
 }
};
let lang="en", playerId=null, card=null, called=[], currentNumber=null, localMode=false;
const $=id=>document.getElementById(id);
const t=key=>(I18N[lang][key]||I18N.en[key]||key);
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function applyLanguage(){document.documentElement.lang=lang;document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=t(el.dataset.i18n));if(card)renderCard();renderCalled()}
$("language").addEventListener("change",e=>{lang=e.target.value;applyLanguage()});
function renderCard(){
 const grid=$("bingo-card");grid.innerHTML="";
 ["B","I","N","G","O"].forEach(letter=>{const h=document.createElement("div");h.className="bingo-head";h.textContent=letter;grid.appendChild(h)});
 card.forEach((row,r)=>row.forEach((num,c)=>{const cell=document.createElement("div");cell.className="bingo-cell";cell.textContent=num===null?"FREE":num;if(num===null)cell.classList.add("free");if(num===null||called.includes(num))cell.classList.add("marked");grid.appendChild(cell)}));
 $("card-status").textContent=t("joined");
}
function renderCalled(){
 $("called-list").innerHTML=called.length?called.slice().reverse().map(n=>`<span class="called-chip">${letterFor(n)}-${n}</span>`).join(""):`<span class="muted">${t("noneYet")}</span>`;
 $("players-count").textContent=playerId?"1":"0";$("numbers-left").textContent=75-called.length;
}
function letterFor(n){return n<=15?"B":n<=30?"I":n<=45?"N":n<=60?"G":"O"}
function makeLocalCard(){
 const cols=[];for(let c=0;c<5;c++){const nums=Array.from({length:15},(_,i)=>c*15+i+1).sort(()=>Math.random()-.5).slice(0,5);cols.push(nums)}
 const rows=Array.from({length:5},(_,r)=>Array.from({length:5},(_,c)=>cols[c][r]));rows[2][2]=null;return rows;
}
async function api(path,method="GET",body){
 const res=await fetch(path,{method,headers:{"Content-Type":"application/json"},body:body?JSON.stringify(body):undefined});
 if(!res.ok)throw new Error((await res.json()).detail||"Request failed");return res.json();
}
$("join-btn").addEventListener("click",async()=>{
 if(playerId)return;
 try{const data=await api("/api/join","POST",{display_name:"Telegram Player"});playerId=data.player_id;card=data.card;called=data.called||[];localMode=false}
 catch(e){localMode=true;playerId="local-demo";card=makeLocalCard();called=[]}
 renderCard();renderCalled();toast(t("joinedToast"));$("join-btn").disabled=true;
});
$("draw-btn").addEventListener("click",async()=>{
 if(!playerId){toast(t("needJoin"));return}
 let n;
 try{const data=await api("/api/call","POST");n=data.number;called=data.called||[...called,n]}
 catch(e){
  const remaining=Array.from({length:75},(_,i)=>i+1).filter(x=>!called.includes(x));
  if(!remaining.length){toast(t("gameOver"));return}
  n=remaining[Math.floor(Math.random()*remaining.length)];called.push(n);
 }
 currentNumber=n;$("current-ball").querySelector("span").textContent=letterFor(n)+" "+n;$("draw-label").textContent=t("drawToast")+letterFor(n)+"-"+n;
 renderCard();renderCalled();
});
function hasLine(){
 const marked=(r,c)=>card[r][c]===null||called.includes(card[r][c]);
 for(let r=0;r<5;r++)if(Array.from({length:5},(_,c)=>marked(r,c)).every(Boolean))return true;
 for(let c=0;c<5;c++)if(Array.from({length:5},(_,r)=>marked(r,c)).every(Boolean))return true;
 if(Array.from({length:5},(_,i)=>marked(i,i)).every(Boolean))return true;
 if(Array.from({length:5},(_,i)=>marked(i,4-i)).every(Boolean))return true;
 return false;
}
$("bingo-btn").addEventListener("click",()=>{if(!playerId){toast(t("needJoin"));return}toast(hasLine()?t("bingoToast"):t("noBingo"))});
$("year").textContent=new Date().getFullYear();
if(window.Telegram?.WebApp){window.Telegram.WebApp.ready();window.Telegram.WebApp.expand();}
applyLanguage();
